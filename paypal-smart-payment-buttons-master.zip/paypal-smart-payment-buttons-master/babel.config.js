/* @flow */
/* eslint import/no-commonjs: off */

module.exports = {
    extends: 'grumbler-scripts/config/.babelrc-node'
};
