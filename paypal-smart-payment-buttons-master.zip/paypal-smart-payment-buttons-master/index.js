/* @flow */
/* eslint import/no-unassigned-import: off, import/no-commonjs: off */

module.exports = require('./server');
