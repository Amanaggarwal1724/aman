/* @flow */

module.exports = {
    'extends': require.resolve('grumbler-scripts/config/.eslintrc-node'),
    
    'rules': {
        'react/display-name': 'off'
    }
};