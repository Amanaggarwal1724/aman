/* @flow */

export const EVENT = {
    RENDER: 'smart_button_render',
    ERROR:  'smart_button_error'
};
