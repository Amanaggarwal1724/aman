/* @flow */

export const EVENT = {
    RENDER: 'menu_render',
    ERROR:  'menu_error'
};
