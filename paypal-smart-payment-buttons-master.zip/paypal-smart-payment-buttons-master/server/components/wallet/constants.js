/* @flow */

export const EVENT = {
    RENDER: 'wallet_render',
    ERROR:  'wallet_error'
};

