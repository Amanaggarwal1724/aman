/* @flow */

export { setupWallet, renderWallet } from './wallet';
