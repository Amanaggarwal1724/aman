/* @flow */

module.exports = {
    'extends': require.resolve('../.eslintrc'),

    'globals': {
        'afterAll': true,
        'jest':     true
    }
};