/* @flow */

declare var afterAll : Function;
